## Primeira entrega do trabalho de algoritmos de ordenação
- A aplicação principal é um programa dotnet escrito em C#
- O arquivo createNumbers.py foi usado para criar a base de dados aleatória
- No arquivo AlgoritmosOrdenacao.csproj encontra-se a versão do dotnet que executa a aplicação
- Se a sua versão do dotnet for diferente, basta colocar o número da sua versão na tag TargetFramework do arquivo csproj
- O ponto de partida da execução de um programa dotnet é o arquivo Program.cs
- A execução dos algoritmos de ordenação gera um arquivo csv com os números ordenados como saída
- buildar programa: dotnet build
- executar o programa: dotnet run









